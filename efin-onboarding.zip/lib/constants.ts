export const OBJECTIVES = ["Ahorrar", "Invertir", "Salir de deudas", "Otro"];
export const LEARNING_PREFERENCES = ["Videos", "Juegos", "Lecturas", "Simuladores"];
export const INTERESTS = ["Cripto", "Inversión", "Economía básica", "VC", "Impuestos", "Deuda"];
